#define PJ_CONFIG_ANDROID 1
#include<pj/config_site_sample.h>
